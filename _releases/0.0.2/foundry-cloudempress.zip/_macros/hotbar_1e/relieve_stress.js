//init vars
let macroTarget = game.settings.get('cloudempress','macroTarget');
//warn user if character is not selected
if ((macroTarget === 'character' && !game.user.character) || (macroTarget === 'token' && !canvas.tokens.controlled.length)) {
  //warn player
  game.mosh.noCharSelected();
//else pop up the dialog
} else {
  new foundry.applications.api.DialogV2({
    window: {
      title: "Relieve Stress"
    },
    classes: ["macro-popup-dialog"],
      position: {width: 600},
      content: `
        <div class ="macro_window" style="margin-bottom : 7px;">
          <div class="grid grid-2col" style="grid-template-columns: 150px auto">
            <div class="macro_img"><img src="systems/cloudempress/images/icons/ui/macros/relieve_stress.png" style="border:none"/></div>
            <div class="macro_desc">
              <h4>Relieve Stress</h4>
              Occasionally, certain moments, places, or events can automatically <strong>relieve your stress.</strong> Escaping perilous situations, finding a serene location, or experiencing a touching moment with a loved one can have meaningful impacts on your mood and outlook on life. If your stress is getting close to 20, you should consider making a <strong>Rest Save</strong> - as the effects of a failed <strong>Panic Check</strong> can be devastating.
            </div>    
          </div>
        </div>
        <div class="macro_prompt">
          Select your modification:
        </div>
      `,
      buttons: [
        {
        label: `Relieve 1 Stress`,
        action: 'button_1',
        callback: () => game.mosh.initModifyActor('system.other.stress.value',-1,null,true),
        icon: `fas fa-angle-down`
        },
        {
        label: `Relieve 2 Stress`,
        action: 'button_2',
        callback: () => game.mosh.initModifyActor('system.other.stress.value',-2,null,true),
        icon: `fas fa-angle-double-down`
        },
        {
        label: `Relieve 1d5 Stress`,
        action: 'button_3',
        callback: () => game.mosh.initModifyActor('system.other.stress.value',null,`-1d5`,true),
        icon: `fas fa-arrow-circle-down`
        }
      ]
  }).render({force: true});
}