//init vars
let macroTarget = game.settings.get('cloudempress','macroTarget');
//warn user if character is not selected
if ((macroTarget === 'character' && !game.user.character) || (macroTarget === 'token' && !canvas.tokens.controlled.length)) {
  //warn player
  game.mosh.noCharSelected();
//else pop up the dialog
} else {
  new foundry.applications.api.DialogV2({
    window: {
      title: "Gain Calm"
    },
    classes: ["macro-popup-dialog"],
    position: {width: 600},
    content: `
      <div class ="macro_window" style="margin-bottom : 7px;">
        <div class="grid grid-2col" style="grid-template-columns: 150px auto">
          <div class="macro_img"><img src="systems/cloudempress/images/icons/ui/macros/relieve_stress.png" style="border:none"/></div>
          <div class="macro_desc">
            <h4>Gain Calm</h4>
            Occasionally, certain moments, places, or events can automatically <strong>calm you down.</strong> Escaping perilous situations, finding a serene location, or experiencing a touching moment with a loved one can have meaningful impacts on your mood and outlook on life. If your Calm is getting close to 0, you should consider making a <strong>Rest Save</strong> - as the effects of a failed <strong>Panic Check</strong> can be devastating.
          </div>    
        </div>
      </div>
      <div class="macro_prompt">
        Select your modification:
      </div>
    `,
    buttons: [
      {
      label: `Gain 5 Calm`,
      action: `gain_5`,
      callback: () => game.mosh.initModifyActor('system.other.stress.value',5,null,true),
      icon: `fas fa-angle-up`
      },
      {
      label: `Gain 10 Calm`,
      action: `gain_10`,
      callback: () => game.mosh.initModifyActor('system.other.stress.value',10,null,true),
      icon: `fas fa-angle-double-up`
      },
      {
      label: `Gain 1d20 Calm`,
      action: `gain_1d20`,
      callback: () => game.mosh.initModifyActor('system.other.stress.value',null,`1d20`,true),
      icon: `fas fa-arrow-circle-up`
      }
    ]
  }).render({force: true});
}